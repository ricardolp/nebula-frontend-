import { useQuery } from '@tanstack/react-query'
import { getForm } from '@/api/forms'
import { useAuthStore } from '@/stores/auth-store'

export function useForm(formId: string | undefined, enabled: boolean) {
  const organizationId = useAuthStore((s) => s.auth.organizationId)
  const token = useAuthStore((s) => s.auth.token)

  const query = useQuery({
    queryKey: ['organization', organizationId, 'form', formId],
    queryFn: () => getForm(organizationId!, formId!, token),
    enabled: Boolean(organizationId && token && formId && enabled),
  })

  const form = query.data?.data.form

  return {
    form,
    isLoading: query.isLoading,
    isPending: query.isPending,
    error: query.error,
    refetch: query.refetch,
  }
}
