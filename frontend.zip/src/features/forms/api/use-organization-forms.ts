import { useQuery } from '@tanstack/react-query'
import { getForms } from '@/api/forms'
import { useAuthStore } from '@/stores/auth-store'

export function useOrganizationForms() {
  const organizationId = useAuthStore((s) => s.auth.organizationId)
  const token = useAuthStore((s) => s.auth.token)

  const query = useQuery({
    queryKey: ['organization', organizationId, 'forms'],
    queryFn: () => getForms(organizationId!, token),
    enabled: Boolean(organizationId && token),
  })

  const forms = query.data?.data.forms ?? []

  return {
    forms,
    isLoading: query.isLoading,
    isPending: query.isPending,
    error: query.error,
    refetch: query.refetch,
  }
}
