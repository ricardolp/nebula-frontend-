import { Shield } from 'lucide-react'

export function ClerkLogo(props: React.SVGAttributes<SVGSVGElement>) {
  return <Shield size={20} {...props} />
}
