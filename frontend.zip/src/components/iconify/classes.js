export const iconifyClasses = {
  root: 'mnl__icon__root',
};
