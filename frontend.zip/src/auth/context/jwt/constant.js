export const STORAGE_KEY = 'jwt_access_token';
export const SESSION_KEY = 'nebula_session';